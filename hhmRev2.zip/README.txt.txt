Breakdown of files in hhmRev2.zip.

    hhmRev2.TXT - drill file
    hhmRev2.GBL - bottom copper
    hhmRev2.GBP - bottom paste
    hhmRev2.GBS - bottom solder
    hhmRev2.GTL - top copper
    hhmRev2.GTP - top paste
    hhmRev2.GTS - top solder
    hhmRev2.GTO - top overlay (silk screen)
    hhmRev2.OLN - outline of the board